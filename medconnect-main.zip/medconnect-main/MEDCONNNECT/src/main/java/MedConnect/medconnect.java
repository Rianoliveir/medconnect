package MedConnect;

import telas.login;

public class medconnect {

    public static void main(String[] args) {
        login login = new login();
        login.setVisible(true);
    }
}
    